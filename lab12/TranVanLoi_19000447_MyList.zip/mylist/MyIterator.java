package lab12.mylist;

public interface MyIterator {
    boolean hasNext();
    Object next();
}
