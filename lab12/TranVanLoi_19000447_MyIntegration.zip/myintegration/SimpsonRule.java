package lab12.myintegration;

public class SimpsonRule implements Integrator {
    private double precision;
    private int maxIterations;

    public SimpsonRule(double precision, int maxIterations) {
        this.precision = precision;
        this.maxIterations = maxIterations;
    }

    @Override
    public double integrate(Polynomial poly, double lower, double upper) {
        int n = 2;
        double integral = integrate(poly, lower, upper, n);
        double prevIntegral;
        int iterations = 0;
        do {
            prevIntegral = integral;
            n *= 2;
            integral = integrate(poly, lower, upper, n);
            iterations++;
        } while (Math.abs(integral - prevIntegral) / 15 >= precision && iterations < maxIterations);
        return integral;
    }

    private double integrate(Polynomial poly, double lower, double upper, int numOfSubIntervals) {
        double sum = 0;
        double step = (upper - lower) / numOfSubIntervals;
        sum += poly.evaluate(lower);
        for (int i = 1; i < numOfSubIntervals; i++) {
            double x = lower + i * step;
            sum += (i % 2 == 0 ? 2 : 4) * poly.evaluate(x);
        }
        sum += poly.evaluate(upper);
        return sum * step / 3;
    }
}
