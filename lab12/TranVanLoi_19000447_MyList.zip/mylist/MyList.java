package lab12.mylist;

public interface MyList extends MyIterable {
    int size();
    Object get(int index);
    void append(Object payload);
    void insert(Object payload, int index);
    void remove(int index);
}
