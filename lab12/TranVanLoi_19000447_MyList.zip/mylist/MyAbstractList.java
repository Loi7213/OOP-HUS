package lab12.mylist;

public abstract class MyAbstractList implements MyList {
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        MyIterator iterator = iterator();
        while (iterator.hasNext()) {
            sb.append(iterator.next()).append("] [");
        }
        if (sb.length() > 1) {
            sb.delete(sb.length() - 3, sb.length());
        }
        sb.append("]");
        return sb.toString();
    }
}
