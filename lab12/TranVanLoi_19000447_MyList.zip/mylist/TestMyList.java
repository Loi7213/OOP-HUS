package lab12.mylist;

public class TestMyList {
    public static void main(String[] args) {
        testMyArrayList();
        testMyLinkedList();
    }

    public static void testMyArrayList() {
        MyArrayList list = new MyArrayList();
        list.append(1.0);
        list.append(2.0);
        list.append(3.0);
        list.append(4.0);
        list.append(5.0);

        BasicStatistic stats = new BasicStatistic(list);
        System.out.println("MyArrayList:");
        System.out.println("Data: " + list);
        System.out.println("Max: " + stats.max());
        System.out.println("Min: " + stats.min());
        System.out.println("Mean: " + stats.mean());
        System.out.println("Variance: " + stats.variance());
    }

    public static void testMyLinkedList() {
        MyLinkedList list = new MyLinkedList();
        list.append(1.0);
        list.append(2.0);
        list.append(3.0);
        list.append(4.0);
        list.append(5.0);

        BasicStatistic stats = new BasicStatistic(list);
        System.out.println("\nMyLinkedList:");
        System.out.println("Data: " + list);
        System.out.println("Max: " + stats.max());
        System.out.println("Min: " + stats.min());
        System.out.println("Mean: " + stats.mean());
        System.out.println("Variance: " + stats.variance());
    }
}
