package lab12.myintegration;

import java.util.ArrayList;
import java.util.List;

public class ListPolynomial extends AbstractPolynomial {
    private List<Double> coefficients;

    public ListPolynomial(double[] differentiate) {
        this.coefficients = new ArrayList<>();
    }

    @Override
    public double coefficient(int index) {
        if (index < 0 || index >= coefficients.size()) {
            return 0;
        }
        return coefficients.get(index);
    }

    @Override
    public double[] coefficients() {
        double[] result = new double[coefficients.size()];
        for (int i = 0; i < coefficients.size(); i++) {
            result[i] = coefficients.get(i);
        }
        return result;
    }

    public ListPolynomial append(double coefficient) {
        coefficients.add(coefficient);
        return this;
    }

    public ListPolynomial insert(double coefficient, int index, int i) {
        if (index < 0 || index > coefficients.size()) {
            throw new IndexOutOfBoundsException();
        }
        coefficients.add(index, coefficient);
        return this;
    }

    public ListPolynomial set(double coefficient, int index) {
        if (index < 0 || index >= coefficients.size()) {
            throw new IndexOutOfBoundsException();
        }
        coefficients.set(index, coefficient);
        return this;
    }

    @Override
    public int degree() {
        return coefficients.size() - 1;
    }

    @Override
    public double evaluate(double x) {
        double result = 0;
        for (int i = coefficients.size() - 1; i >= 0; i--) {
            result = result * x + coefficients.get(i);
        }
        return result;
    }

    @Override
    public Polynomial derivative() {
        return new ListPolynomial(differentiate());
    }

    public ListPolynomial plus(ListPolynomial another) {
        ListPolynomial result = new ListPolynomial(differentiate());
        int maxSize = Math.max(coefficients.size(), another.coefficients.size());
        for (int i = 0; i < maxSize; i++) {
            result.append(coefficient(i) + another.coefficient(i));
        }
        return result;
    }

    public ListPolynomial minus(ListPolynomial another) {
        ListPolynomial result = new ListPolynomial(differentiate());
        int maxSize = Math.max(coefficients.size(), another.coefficients.size());
        for (int i = 0; i < maxSize; i++) {
            result.append(coefficient(i) - another.coefficient(i));
        }
        return result;
    }

    public ListPolynomial multiply(ListPolynomial another) {
        ListPolynomial result = new ListPolynomial(differentiate());
        for (int i = 0; i < coefficients.size(); i++) {
            for (int j = 0; j < another.coefficients.size(); j++) {
                result.append(coefficients.get(i) * another.coefficients.get(j));
            }
            result.insert(0, 0, i + another.coefficients.size());
        }
        return result;
    }
}
