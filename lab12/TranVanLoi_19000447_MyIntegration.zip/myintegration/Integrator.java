package lab12.myintegration;

public interface Integrator {
    double integrate(Polynomial poly, double lower, double upper);
}
