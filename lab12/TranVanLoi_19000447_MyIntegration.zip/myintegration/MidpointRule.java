package lab12.myintegration;

public class MidpointRule implements Integrator {
    private double precision;
    private int maxIterations;

    public MidpointRule(double precision, int maxIterations) {
        this.precision = precision;
        this.maxIterations = maxIterations;
    }

    @Override
    public double integrate(Polynomial poly, double lower, double upper) {
        int n = 1;
        double integral = integrate(poly, lower, upper, n);
        double prevIntegral;
        int iterations = 0;
        do {
            prevIntegral = integral;
            n *= 2;
            integral = integrate(poly, lower, upper, n);
            iterations++;
        } while (Math.abs(integral - prevIntegral) / 3 >= precision && iterations < maxIterations);
        return integral;
    }

    private double integrate(Polynomial poly, double upper, double lower, int numOfSubIntervals) {
        double sum = 0;
        double step = (upper - lower) / numOfSubIntervals;
        for (int i = 1; i <= numOfSubIntervals; i++) {
            sum += poly.evaluate(lower + (i - 0.5) * step);
        }
        return sum * step;
    }
}
