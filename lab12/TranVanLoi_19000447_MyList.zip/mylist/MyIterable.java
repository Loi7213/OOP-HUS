package lab12.mylist;

public interface MyIterable {
    MyIterator iterator();
}
