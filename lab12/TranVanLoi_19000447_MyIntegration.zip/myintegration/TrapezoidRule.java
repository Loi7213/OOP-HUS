package lab12.myintegration;

public class TrapezoidRule implements Integrator {
    private double precision;
    private int maxIterations;

    public TrapezoidRule(double precision, int maxIterations) {
        this.precision = precision;
        this.maxIterations = maxIterations;
    }

    @Override
    public double integrate(Polynomial poly, double lower, double upper) {
        int n = 1;
        double integral = integrate(poly, lower, upper, n);
        double prevIntegral;
        int iterations = 0;
        do {
            prevIntegral = integral;
            n *= 2;
            integral = integrate(poly, lower, upper, n);
            iterations++;
        } while (Math.abs(integral - prevIntegral) / 3 >= precision && iterations < maxIterations);
        return integral;
    }

    private double integrate(Polynomial poly, double lower, double upper, int numOfSubIntervals) {
        double sum = 0;
        double step = (upper - lower) / numOfSubIntervals;
        sum += poly.evaluate(lower);
        for (int i = 1; i < numOfSubIntervals; i++) {
            sum += 2 * poly.evaluate(lower + i * step);
        }
        sum += poly.evaluate(upper);
        return sum * step / 2;
    }
}
