package lab12.myintegration;

public class IntegrationCalculatorTestDrive {
    public static void main(String[] args) {
        testArrayPolynomial();
        testListPolynomial();
        testIntegrationCalculator();
    }

    public static void testArrayPolynomial() {
        ArrayPolynomial poly1 = new ArrayPolynomial(differentiate());
        poly1.append(1).append(2).append(3);
        System.out.println("Polynomial 1: " + poly1);
        System.out.println("Degree: " + poly1.degree());
        System.out.println("Evaluate at x = 2: " + poly1.evaluate(2));
        System.out.println("Derivative: " + poly1.derivative());

        ArrayPolynomial poly2 = new ArrayPolynomial(differentiate());
        poly2.append(4).append(5).append(6);
        System.out.println("\nPolynomial 2: " + poly2);

        System.out.println("\nSum of poly1 and poly2: " + poly1.plus(poly2));
        System.out.println("Difference of poly1 and poly2: " + poly1.minus(poly2));
        System.out.println("Product of poly1 and poly2: " + poly1.multiply(poly2));
    }

    private static double[] differentiate() {
        return new double[0];
    }

    public static void testListPolynomial() {
        ListPolynomial poly1 = new ListPolynomial(differentiate());
        poly1.append(1).append(2).append(3);
        System.out.println("\nPolynomial 1: " + poly1);
        System.out.println("Degree: " + poly1.degree());
        System.out.println("Evaluate at x = 2: " + poly1.evaluate(2));
        System.out.println("Derivative: " + poly1.derivative());

        ListPolynomial poly2 = new ListPolynomial(differentiate());
        poly2.append(4).append(5).append(6);
        System.out.println("\nPolynomial 2: " + poly2);

        System.out.println("\nSum of poly1 and poly2: " + poly1.plus(poly2));
        System.out.println("Difference of poly1 and poly2: " + poly1.minus(poly2));
        System.out.println("Product of poly1 and poly2: " + poly1.multiply(poly2));
    }

    public static void testIntegrationCalculator() {
        ArrayPolynomial poly = new ArrayPolynomial(differentiate());
        poly.append(1).append(2).append(3).append(4);
        System.out.println("\nPolynomial: " + poly);

        IntegrationCalculator calculator = new IntegrationCalculator(poly);

        Integrator trapezoidRule = new TrapezoidRule(1e-6, 100);
        calculator.setIntegrator(trapezoidRule);
        System.out.println("\nTrapezoid Rule:");
        System.out.println("Integral from 0 to 1: " + calculator.integrate(0, 1));

        Integrator simpsonRule = new SimpsonRule(1e-6, 100);
        calculator.setIntegrator(simpsonRule);
        System.out.println("\nSimpson Rule:");
        System.out.println("Integral from 0 to 1: " + calculator.integrate(0, 1));

        Integrator midpointRule = new MidpointRule(1e-6, 100);
        calculator.setIntegrator(midpointRule);
        System.out.println("\nMidpoint Rule:");
        System.out.println("Integral from 0 to 1: " + calculator.integrate(0, 1));
    }
}
