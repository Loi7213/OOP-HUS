package lab12.myintegration;

public abstract class AbstractPolynomial implements Polynomial {
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        double[] coefficients = coefficients();
        for (int i = coefficients.length - 1; i >= 0; i--) {
            if (coefficients[i] != 0) {
                if (i == 0) {
                    sb.append(coefficients[i]);
                } else if (i == 1) {
                    sb.append(coefficients[i]).append("x + ");
                } else {
                    sb.append(coefficients[i]).append("x^").append(i).append(" + ");
                }
            }
        }
        if (sb.length() > 0 && sb.charAt(sb.length() - 1) == ' ') {
            sb.delete(sb.length() - 3, sb.length());
        }
        return sb.toString();
    }

    public double[] differentiate() {
        double[] coefficients = coefficients();
        double[] derivativeCoefficients = new double[coefficients.length - 1];
        for (int i = 1; i < coefficients.length; i++) {
            derivativeCoefficients[i - 1] = i * coefficients[i];
        }
        return derivativeCoefficients;
    }
}
